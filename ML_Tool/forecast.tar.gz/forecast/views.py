# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.core.files.storage import FileSystemStorage
from fbprophet import Prophet
from forecast_models import (
                h2oGBE,
                dataColumns,
                h2oRFE,
                h2oGLE,
                XGBR,
                RFR,
                GBR,
                generateTestDataFrame,
            )
import csv
import pandas as pd
import numpy as np

def fb_prophet_prediction(df, granular_name, target_column, no_of_days):

	""" Forecasting the timeseries data based on Facebook Prophet."""

	#df = df.rename(columns={'date':'ds', 'Quantity':'y'})
	df = df.rename(columns={'date':'ds', 'Views':'y'})
	df["y_orig"] = df['y']
        df['y'] = np.log(df['y'])

        # creating prophet object and training on data
	prophet = Prophet(growth='linear', daily_seasonality=True)
	prophet.fit(df)

	# creating the future dates that prophet will predict
	# specified frequency.
        freq_set = {'Day': 'd', 'Week':'w','Month':'m'}
	future = prophet.make_future_dataframe(freq=freq_set[granular_name], periods=int(no_of_days))

	# predicting the values 
	forecast = prophet.predict(future)
        output_df = forecast[['ds', 'yhat']].tail(int(no_of_days))
        npp = np.exp(forecast[['yhat', 'yhat_lower', 'yhat_upper']].tail(int(no_of_days)))
	#output_df = forecast[['ds', 'yhat']]
        merged_df = pd.merge(output_df, npp, left_index=True, right_index=True)
        final_output = merged_df[['ds', 'yhat_y']]
	return final_output

# Create your views here.
@csrf_exempt
def home(request):
        if request.method == "POST":
            algo_name = request.POST.get('algorithm', '')
            granular_name = request.POST.get('granualarity', '')
            target_column = request.POST.get('targetColumn', '')
            data = pd.read_csv(request.FILES['inputGroupSuccess2'])
            if not data.empty:
                data['date'] = data['date'].astype('datetime64[ns]')
                data['date'] = data['date'].dt.date
            no_of_days = request.POST.get('no_of_days', '')
            print  data.head()
            testData = None#generateTestDataFrame(trainData=data, days=no_of_days, gname=granular_name)
            if algo_name == 'XGBRegressor':
                data = XGBR(trainData=data, days=no_of_days)
            elif algo_name == 'RandomForestRegressor':
                data = RFR(trainData=data, days=no_of_days)
            elif algo_name == 'GradientBoostingRegressor':
                data = GBR(trainData=data, days=no_of_days)
            elif algo_name == 'H2OGradientBoostingEstimator':
                data = h2oGBE(trainData=data, testData=testData, targetColumn=target_column, featuresColumns=[])
            elif algo_name == 'H2ORandomForestEstimator':
                data = h2oRFE(trainData=data, testData=testData, targetColumn=target_column, featuresColumns=[])
            elif algo_name == 'H2OGeneralizedLinearEstimator':
                data = h2oGLE(trainData=data, testData=testData, targetColumn=target_column, featuresColumns=[])
	    elif algo_name == "FB_Prophet":
		data = fb_prophet_prediction(data, granular_name, target_column, no_of_days)
            response = HttpResponse(content_type='application/vnd.csv')
            response['Content-Disposition'] = 'attachment; filename=result.csv'
            data.to_csv(response,index=False, encoding='utf-8')
            return response
        return render(request, 'test.html')
